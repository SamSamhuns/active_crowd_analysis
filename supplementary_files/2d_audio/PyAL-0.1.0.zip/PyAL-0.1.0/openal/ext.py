"""OpenAL extensions"""
__all__ = []
