.. module:: openal.loaders
   :synopsis: Easy sound loading supports

openal.loaders - loading sounds
===============================

.. todo::

   Outline

API
^^^

.. function:: load_file(fname : string) -> SoundData

   Loads an audio file into a :class:`SoundData` object.

.. function:: load_stream(source : object) -> SoundData

   Not implemented yet.

.. function:: load_wav_file(fname : string) -> SoundData

   Loads a WAV audio file into a :class:`SoundData` object.
