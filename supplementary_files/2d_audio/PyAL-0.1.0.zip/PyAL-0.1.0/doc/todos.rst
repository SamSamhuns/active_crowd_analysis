Todo list for PyAL
==================

* proper unit tests
* more examples